function validateform() {
if ( document.getElementById('name').value === ''|| document.getElementById('password').value === '') {
var op="Please Fill All the Required Fields";
document.getElementById("result").innerHTML=op;
return false;
}
else{
var np="Success";
document.getElementById("result").innerHTML=np;
return true;
}}